# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['wiki_based_doc_classifier',
 'wiki_based_doc_classifier.classifiers',
 'wiki_based_doc_classifier.corpus',
 'wiki_based_doc_classifier.datasets',
 'wiki_based_doc_classifier.model_selection']

package_data = \
{'': ['*']}

install_requires = \
['numpy>=1.22.3,<2.0.0', 'scikit-learn>=1.0.2,<2.0.0']

setup_kwargs = {
    'name': 'wiki-based-doc-classifier',
    'version': '0.1.0',
    'description': 'wiki-based-doc-classifier - Wikipedia-based Document Classifier',
    'long_description': None,
    'author': 'Nick',
    'author_email': 'n.cardelli2@outlook.it',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
